<?php
/**
 * Admin Menu and Logic
 */

if (!defined('ABSPATH')) {
    exit;
}

class HBS_Admin_Menu
{
    private $loader;

    public function __construct($loader)
    {
        $this->loader = $loader;

        // Add menu
        $this->loader->add_action('admin_menu', $this, 'register_menu');

        // Save settings action
        $this->loader->add_action('admin_post_hbs_save_settings', $this, 'save_settings');
    }

    public function register_menu()
    {
        add_menu_page(
            __('Hotel Booking', 'hotel-booking-system'),
            __('Hotel Booking', 'hotel-booking-system'),
            'manage_options',
            'hbs_settings',
            [$this, 'render_settings_page'],
            'dashicons-calendar-alt',
            56
        );

        add_submenu_page(
            'hbs_settings',
            __('Ajustes', 'hotel-booking-system'),
            __('Ajustes', 'hotel-booking-system'),
            'manage_options',
            'hbs_settings',
            [$this, 'render_settings_page']
        );

        add_submenu_page(
            'hbs_settings',
            __('Reservaciones recientes', 'hotel-booking-system'),
            __('Reservaciones recientes', 'hotel-booking-system'),
            'manage_options',
            'hbs_recent_bookings',
            [$this, 'render_recent_bookings_page']
        );
    }

    public function render_settings_page()
    {
        if (!current_user_can('manage_options')) {
            return;
        }
        include plugin_dir_path(__FILE__) . 'views/settings-page.php';
    }

    public function render_recent_bookings_page()
    {
        if (!current_user_can('manage_options')) {
            return;
        }
        include plugin_dir_path(__FILE__) . 'views/recent-bookings-page.php';
    }

    public function save_settings()
    {
        if (!current_user_can('manage_options')) {
            wp_die(__('Permisos insuficientes.', 'hotel-booking-system'));
        }

        // Verify nonce using HBS_Config constants
        check_admin_referer(HBS_Config::NONCE_ACTION, HBS_Config::NONCE_KEY);

        $input = $_POST;
        $settings = [];

        // Sanitize fields
        $settings['staff_emails'] = sanitize_text_field($input['staff_emails']);
        $settings['policies_url'] = esc_url_raw($input['policies_url']);
        $settings['price_single'] = floatval($input['price_single']);
        $settings['price_double'] = floatval($input['price_double']);
        $settings['price_extra_adult'] = floatval($input['price_extra_adult']);
        $settings['price_extra_kid'] = floatval($input['price_extra_kid']);
        $settings['floating_enabled'] = isset($input['floating_enabled']) ? 1 : 0;
        $settings['guest_email_note'] = sanitize_textarea_field($input['guest_email_note']);

        // Optional booking URL for floating form redirect
        if (isset($input['booking_page_url'])) {
            $settings['booking_page_url'] = esc_url_raw($input['booking_page_url']);
        }

        update_option(HBS_Config::OPTION_KEY, $settings);

        wp_redirect(admin_url('admin.php?page=hbs_settings&hbs_saved=true'));
        exit;
    }
}
