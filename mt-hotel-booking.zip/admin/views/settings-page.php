<?php
if (!defined('ABSPATH')) {
    exit;
}

$opts = get_option(HBS_Config::OPTION_KEY, []);

// Defaults for display if not set
$staff_emails = isset($opts['staff_emails']) ? $opts['staff_emails'] : get_option('admin_email');
$policies_url = isset($opts['policies_url']) ? $opts['policies_url'] : '';
$p_single = isset($opts['price_single']) ? $opts['price_single'] : '1850.00';
$p_double = isset($opts['price_double']) ? $opts['price_double'] : '2100.00';
$p_ex_adult = isset($opts['price_extra_adult']) ? $opts['price_extra_adult'] : '450.00';
$p_ex_kid = isset($opts['price_extra_kid']) ? $opts['price_extra_kid'] : '250.00';
$floating = !empty($opts['floating_enabled']);
$note = isset($opts['guest_email_note']) ? $opts['guest_email_note'] : '';
$book_url = isset($opts['booking_page_url']) ? $opts['booking_page_url'] : '';
?>

<div class="wrap">
    <h1><?php echo esc_html__('Hotel Booking — Ajustes', 'hotel-booking-system'); ?></h1>

    <?php if (isset($_GET['hbs_saved'])): ?>
        <div class="notice notice-success is-dismissible">
            <p><?php echo esc_html__('Ajustes guardados correctamente.', 'hotel-booking-system'); ?></p>
        </div>
    <?php endif; ?>

    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
        <input type="hidden" name="action" value="hbs_save_settings">
        <?php wp_nonce_field(HBS_Config::NONCE_ACTION, HBS_Config::NONCE_KEY); ?>

        <table class="form-table" role="presentation">
            <tr>
                <th scope="row"><label
                        for="staff_emails"><?php echo esc_html__('Emails Staff', 'hotel-booking-system'); ?></label>
                </th>
                <td>
                    <input name="staff_emails" type="text" id="staff_emails"
                        value="<?php echo esc_attr($staff_emails); ?>" class="regular-text">
                    <p class="description"><?php echo esc_html__('Separados por comas.', 'hotel-booking-system'); ?>
                    </p>
                </td>
            </tr>
            <tr>
                <th scope="row"><label
                        for="policies_url"><?php echo esc_html__('URL Políticas', 'hotel-booking-system'); ?></label>
                </th>
                <td>
                    <input name="policies_url" type="url" id="policies_url"
                        value="<?php echo esc_attr($policies_url); ?>" class="regular-text">
                </td>
            </tr>

            <tr>
                <th colspan="2">
                    <h3><?php echo esc_html__('Precios Base (MXN)', 'hotel-booking-system'); ?></h3>
                </th>
            </tr>

            <tr>
                <th scope="row"><label
                        for="price_single"><?php echo esc_html__('Sencilla (Base 2)', 'hotel-booking-system'); ?></label>
                </th>
                <td><input name="price_single" type="number" step="0.01" id="price_single"
                        value="<?php echo esc_attr($p_single); ?>" class="regular-text"></td>
            </tr>
            <tr>
                <th scope="row"><label
                        for="price_double"><?php echo esc_html__('Doble (Base 2)', 'hotel-booking-system'); ?></label>
                </th>
                <td><input name="price_double" type="number" step="0.01" id="price_double"
                        value="<?php echo esc_attr($p_double); ?>" class="regular-text"></td>
            </tr>
            <tr>
                <th scope="row"><label
                        for="price_extra_adult"><?php echo esc_html__('Adulto Extra', 'hotel-booking-system'); ?></label>
                </th>
                <td><input name="price_extra_adult" type="number" step="0.01" id="price_extra_adult"
                        value="<?php echo esc_attr($p_ex_adult); ?>" class="regular-text"></td>
            </tr>
            <tr>
                <th scope="row"><label
                        for="price_extra_kid"><?php echo esc_html__('Niño Extra (>4)', 'hotel-booking-system'); ?></label>
                </th>
                <td><input name="price_extra_kid" type="number" step="0.01" id="price_extra_kid"
                        value="<?php echo esc_attr($p_ex_kid); ?>" class="regular-text"></td>
            </tr>

            <tr>
                <th colspan="2">
                    <h3><?php echo esc_html__('Otros', 'hotel-booking-system'); ?></h3>
                </th>
            </tr>

            <tr>
                <th scope="row"><?php echo esc_html__('Formulario Flotante', 'hotel-booking-system'); ?></th>
                <td>
                    <label for="floating_enabled">
                        <input name="floating_enabled" type="checkbox" id="floating_enabled" value="1" <?php checked($floating, true); ?>>
                        <?php echo esc_html__('Activar en footer (Desktop)', 'hotel-booking-system'); ?>
                    </label>
                </td>
            </tr>
            <tr>
                <th scope="row"><label
                        for="booking_page_url"><?php echo esc_html__('URL Página Reservación', 'hotel-booking-system'); ?></label>
                </th>
                <td>
                    <input name="booking_page_url" type="url" id="booking_page_url"
                        value="<?php echo esc_attr($book_url); ?>" class="regular-text">
                    <p class="description">
                        <?php echo esc_html__('Requerido para que funcione el formulario flotante (redirección).', 'hotel-booking-system'); ?>
                    </p>
                </td>
            </tr>
            <tr>
                <th scope="row"><label
                        for="guest_email_note"><?php echo esc_html__('Nota Email Huésped', 'hotel-booking-system'); ?></label>
                </th>
                <td>
                    <textarea name="guest_email_note" id="guest_email_note" rows="3"
                        class="large-text code"><?php echo esc_textarea($note); ?></textarea>
                    <p class="description">
                        <?php echo esc_html__('Mensaje opcional al final del email de confirmación.', 'hotel-booking-system'); ?>
                    </p>
                </td>
            </tr>
        </table>

        <?php submit_button(); ?>
    </form>
</div>