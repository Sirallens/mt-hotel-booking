<?php
if (!defined('ABSPATH')) {
    exit;
}

$bookings = HBS_Booking::get_recent(10);
?>

<div class="wrap">
    <h1><?php echo esc_html__('Reservaciones recientes', 'hotel-booking-system'); ?></h1>

    <table class="wp-list-table widefat fixed striped table-view-list">
        <thead>
            <tr>
                <th>ID</th>
                <th><?php echo esc_html__('Fecha Solicitud', 'hotel-booking-system'); ?></th>
                <th><?php echo esc_html__('Status', 'hotel-booking-system'); ?></th>
                <th><?php echo esc_html__('Huésped', 'hotel-booking-system'); ?></th>
                <th><?php echo esc_html__('Fechas Estancia', 'hotel-booking-system'); ?></th>
                <th><?php echo esc_html__('Detalles', 'hotel-booking-system'); ?></th>
                <th><?php echo esc_html__('Total (MXN)', 'hotel-booking-system'); ?></th>
            </tr>
        </thead>
        <tbody>
            <?php if (!empty($bookings)): ?>
                <?php foreach ($bookings as $b): ?>
                    <tr>
                        <td>#<?php echo intval($b['booking_id']); ?></td>
                        <td><?php echo esc_html($b['created_date']); ?></td>
                        <td>
                            <?php
                            $status_color = '#eee'; // default
                            if ('pending' === $b['booking_status'])
                                $status_color = '#ffeeba'; // yellow
                            elseif ('confirmed' === $b['booking_status'])
                                $status_color = '#c3e6cb'; // green
                            elseif ('cancelled' === $b['booking_status'])
                                $status_color = '#f5c6cb'; // red
                            ?>
                            <span
                                style="background:<?php echo $status_color; ?>;padding:4px 8px;border-radius:4px;font-weight:bold;font-size:11px;">
                                <?php echo esc_html(ucfirst($b['booking_status'])); ?>
                            </span>
                        </td>
                        <td>
                            <strong><?php echo esc_html($b['guest_name']); ?></strong><br>
                            <a
                                href="mailto:<?php echo esc_attr($b['guest_email']); ?>"><?php echo esc_html($b['guest_email']); ?></a><br>
                            <?php echo esc_html($b['guest_phone']); ?>
                        </td>
                        <td>
                            In: <?php echo esc_html($b['check_in_date']); ?><br>
                            Out: <?php echo esc_html($b['check_out_date']); ?>
                        </td>
                        <td>
                            <?php
                            echo sprintf(
                                esc_html__('%s | A: %d | N: %d', 'hotel-booking-system'),
                                ('single' === $b['room_type'] ? 'Sencilla' : 'Doble'),
                                $b['adults_count'],
                                $b['kids_count']
                            );
                            ?>
                        </td>
                        <td>$<?php echo number_format($b['total_price'], 2); ?></td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="7"><?php echo esc_html__('No hay reservaciones recientes.', 'hotel-booking-system'); ?>
                    </td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>